/* 
 * File:   main.h
 * Author: miles
 *
 * Created on August 5, 2014, 10:21 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#include "lightSky.h"

enum {
    TEST_MAX_KEYBORD_STATES = 282, // according to https://wiki.libsdl.org/SDLScancodeLookup
};

#endif	/* MAIN_H */

