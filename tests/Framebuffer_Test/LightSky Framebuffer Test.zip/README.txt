LightSky Framebuffer Test

-------------------
Controls
-------------------
ESCAPE          Quit the test program
SPACE           Generate a new texture
W               Move Forward
S               Move Backward
A               Strafe Left
D               Strafe Right
MOUSE WHEEL     Increase/Decrease the resolution
LMB             Capture the mouse within the window
RMB             Release the mouse from the window